"""Driver AI Assistant - Full Bot (starter)
Features:
- Registration (save driver info)
- Menu with buttons
- Upload documents (store file_ids)
- Earnings calculator (simple input)
- Subscribe link (Paystack)
- Admin broadcast
- Save data to SQLite
- Scheduled daily reminders (APScheduler)
- Placeholder hooks for OpenAI, Google Maps, Weather, Events APIs
- Webhook-ready (Flask) and polling support
"""

import os
import logging
import sqlite3
import datetime
from functools import wraps

from telegram import (
    Update, ReplyKeyboardMarkup, ReplyKeyboardRemove
)
from telegram.ext import (
    Application, CommandHandler, MessageHandler, ConversationHandler,
    filters, ContextTypes
)

# Optional Flask imports for webhook mode
from flask import Flask, request, jsonify

# Scheduler
from apscheduler.schedulers.background import BackgroundScheduler

# ---------------------------
# Config & Logging
# ---------------------------
TELEGRAM_TOKEN = os.environ.get("TELEGRAM_TOKEN", "PUT_YOUR_TOKEN")
PAYSTACK_LINK = os.environ.get("PAYSTACK_LINK", "https://paystack.com/pay/your-link")
ADMIN_USER_ID = int(os.environ.get("ADMIN_USER_ID", "0"))
WEBHOOK_URL = os.environ.get("WEBHOOK_URL")  # if set, use webhook mode

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logger = logging.getLogger(__name__)

# ---------------------------
# Database (SQLite simple)
# ---------------------------
DB_PATH = "drivers.db"

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS drivers (
            tg_id INTEGER PRIMARY KEY,
            name TEXT,
            phone TEXT,
            city TEXT,
            subscribed INTEGER DEFAULT 0,
            sub_expires TEXT,
            doc_file_id TEXT,
            joined_at TEXT
        )
    ''')
    conn.commit()
    conn.close()

def save_driver(tg_id, name=None, phone=None, city=None):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    now = datetime.datetime.utcnow().isoformat()
    c.execute('SELECT tg_id FROM drivers WHERE tg_id=?', (tg_id,))
    if c.fetchone():
        c.execute('''
            UPDATE drivers SET name=?, phone=?, city=? WHERE tg_id=?
        ''', (name, phone, city, tg_id))
    else:
        c.execute('''
            INSERT INTO drivers (tg_id, name, phone, city, joined_at) VALUES (?,?,?,?,?)
        ''', (tg_id, name, phone, city, now))
    conn.commit()
    conn.close()

def set_subscription(tg_id, months=1):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    expires = (datetime.datetime.utcnow() + datetime.timedelta(days=30*months)).isoformat()
    c.execute('UPDATE drivers SET subscribed=1, sub_expires=? WHERE tg_id=?', (expires, tg_id))
    conn.commit()
    conn.close()

def is_subscribed(tg_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('SELECT subscribed, sub_expires FROM drivers WHERE tg_id=?', (tg_id,))
    r = c.fetchone()
    conn.close()
    if not r:
        return False
    subscribed, sub_expires = r
    if not subscribed:
        return False
    if sub_expires:
        exp = datetime.datetime.fromisoformat(sub_expires)
        return exp > datetime.datetime.utcnow()
    return False

def store_doc_file(tg_id, file_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('UPDATE drivers SET doc_file_id=? WHERE tg_id=?', (file_id, tg_id))
    conn.commit()
    conn.close()

# ---------------------------
# Utilities
# ---------------------------
def admin_only(func):
    @wraps(func)
    async def wrapped(update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        if not user or user.id != ADMIN_USER_ID:
            await update.message.reply_text("You are not authorized to use this command.")
            return
        return await func(update, context)
    return wrapped

# ---------------------------
# Bot Handlers
# ---------------------------
MENU_KEYS = [
    ["📌 Tips & Tricks", "🚘 Car Deals"],
    ["💰 Subscribe VIP", "🧾 Earnings Calc"],
    ["📤 Upload Docs", "📞 Support"]
]

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    keyboard = ReplyKeyboardMarkup(MENU_KEYS, resize_keyboard=True)
    await update.message.reply_text(
        "🚖 Welcome to Driver Assistant!\nChoose an option below:",
        reply_markup=keyboard
    )
    # auto-register
    if user:
        save_driver(user.id, name=user.full_name)

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "/start - show menu\n/help - this help\n/stats - (admin) show counts\n/broadcast - (admin) send message to all"
    )

async def tips(update: Update, context: ContextTypes.DEFAULT_TYPE):
    tg_id = update.effective_user.id
    if is_subscribed(tg_id):
        text = ("🔥 VIP Tip:\nDrive during rainy evenings near malls & hospitals. Keep acceptance >85%.")
    else:
        text = ("💡 Tip:\nDrive during peak hours 6–9am and 4–8pm. Try airport pickups and big malls.")
    await update.message.reply_text(text)

async def cards(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🚘 Car Leasing Partners:\n- Moove Africa\n- FlexClub\n- Local rental partners\nContact support for numbers."
    )

# Simple earnings calculator conversation
EARN_AMOUNT, EARN_HOURS = range(2)
async def earnings_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Enter average fare per trip in Rands (e.g., 80):", reply_markup=ReplyKeyboardRemove())
    return EARN_AMOUNT

async def earnings_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    try:
        fare = float(text)
        context.user_data['fare'] = fare
        await update.message.reply_text("Enter average trips per hour (e.g., 2):")
        return EARN_HOURS
    except:
        await update.message.reply_text("Please send a number for fare (e.g., 80).")
        return EARN_AMOUNT

async def earnings_hours(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    try:
        trips = float(text)
        fare = context.user_data.get('fare', 0)
        estimated = fare * trips * 8  # assume 8-hour day
        await update.message.reply_text(f"Estimated daily earnings (8h): R{estimated:.2f}\nWeekly ~ R{estimated*7:.2f}")
    except:
        await update.message.reply_text("Please send a number for trips per hour.")
    return ConversationHandler.END

# Upload docs
async def upload_docs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Please send a photo or file of your driver's licence or ID (do not send private photos).")

async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE):
    doc = update.message.document or (update.message.photo[-1] if update.message.photo else None)
    if not doc:
        await update.message.reply_text("No document found. Please send a file or photo.")
        return
    file_id = doc.file_id if hasattr(doc, 'file_id') else doc.file_id
    tg_id = update.effective_user.id
    store_doc_file(tg_id, file_id)
    await update.message.reply_text("Thanks! Document saved (we store a Telegram file id).")

# Support
async def support(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Contact support: WhatsApp +27 60 000 0000")

# Admin: stats and broadcast
@admin_only
async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('SELECT COUNT(*) FROM drivers')
    total = c.fetchone()[0]
    c.execute('SELECT COUNT(*) FROM drivers WHERE subscribed=1')
    subs = c.fetchone()[0]
    conn.close()
    await update.message.reply_text(f"Total users: {total}\nSubscribers: {subs}")

@admin_only
async def broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = " ".join(context.args) if context.args else ""
    if not text:
        await update.message.reply_text("Usage: /broadcast Your message here")
        return
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('SELECT tg_id FROM drivers')
    rows = c.fetchall()
    conn.close()
    sent = 0
    for (tg_id,) in rows:
        try:
            await context.bot.send_message(chat_id=tg_id, text=text)
            sent += 1
        except Exception as e:
            logger.warning("Failed to send to %s: %s", tg_id, e)
    await update.message.reply_text(f"Broadcast sent to {sent} users.")

# Message router for menu
async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (update.message.text or "").strip()
    if text == "📌 Tips & Tricks":
        await tips(update, context)
    elif text == "🚘 Car Deals":
        await cards(update, context)
    elif text == "💰 Subscribe VIP":
        await update.message.reply_text(f"Subscribe here: {PAYSTACK_LINK}")
    elif text == "🧾 Earnings Calc":
        return await earnings_start(update, context)
    elif text == "📤 Upload Docs":
        await upload_docs(update, context)
    elif text == "📞 Support":
        await support(update, context)
    else:
        await update.message.reply_text("Please use the menu buttons.")

# ---------------------------
# Scheduler tasks
# ---------------------------
sched = BackgroundScheduler()

def daily_broadcast(app):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('SELECT tg_id FROM drivers WHERE subscribed=1')
    rows = c.fetchall()
    conn.close()
    for (tg_id,) in rows:
        try:
            app.bot.send_message(chat_id=tg_id, text="Daily VIP tip: Drive around malls after 6pm for higher fares.")
        except Exception as e:
            logger.warning("Daily tip failed for %s: %s", tg_id, e)

# ---------------------------
# App main (polling or webhook)
# ---------------------------
def build_application():
    init_db()
    app = Application.builder().token(TELEGRAM_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("stats", stats))
    app.add_handler(CommandHandler("broadcast", broadcast))

    conv = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^🧾 Earnings Calc$"), earnings_start)],
        states={
            EARN_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, earnings_amount)],
            EARN_HOURS: [MessageHandler(filters.TEXT & ~filters.COMMAND, earnings_hours)]
        },
        fallbacks=[]
    )
    app.add_handler(conv)

    app.add_handler(MessageHandler(filters.Document.ALL | filters.PHOTO, handle_document))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))

    return app

# Flask webhook wrapper
flask_app = Flask(__name__)
telegram_app = None

@flask_app.route("/health", methods=["GET"])
def health():
    return jsonify({"ok": True})

@flask_app.route("/telegram_webhook", methods=["POST"])
def telegram_webhook():
    update = Update.de_json(request.get_json(force=True), telegram_app.bot)
    telegram_app.post_update(update)
    return "OK"

# Entry
if __name__ == "__main__":
    telegram_app = build_application()

    try:
        sched.add_job(lambda: daily_broadcast(telegram_app), 'cron', hour=6, minute=0)
        sched.start()
    except Exception as e:
        logger.warning("Scheduler start failed: %s", e)

    if WEBHOOK_URL:
        port = int(os.environ.get("PORT", "5000"))
        url = f"{WEBHOOK_URL.rstrip('/')}/telegram_webhook"
        try:
            import requests
            r = requests.get(f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/setWebhook?url={url}")
            logger.info("Set webhook result: %s", r.text)
        except Exception as e:
            logger.warning("Webhook set failed: %s", e)
        telegram_app.run_webhook(listen="0.0.0.0", port=port, url_path="/telegram_webhook")
    else:
        logger.info("Starting polling mode...")
        telegram_app.run_polling()
